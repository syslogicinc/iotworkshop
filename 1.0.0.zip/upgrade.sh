#!/bin/bash
# Install OWASP Juice Shop
sudo apt update
sudo apt install docker.io -y
sudo docker pull bkimminich/juice-shop
sudo docker run --rm -p 3000:3000 bkimminich/juice-shop
